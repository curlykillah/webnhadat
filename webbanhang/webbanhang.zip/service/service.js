myApp.service('homeService', function () {
    var seft = this;
    this.name = "page1";

});


