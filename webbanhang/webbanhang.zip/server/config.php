<?php	
	header("Content-Type: text/html; charset=utf-8");
	define('HOST', 'localhost');
	define('USERNAME','root'); // Tài Khoản
	define('USERPASSWORD', ''); // Password DB
	define('SQL', 'shop'); // DB Kết nối
	
?>